package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_WEIGHT = "weight_history";
    private static final String COL_ID = "id";
    private static final String COL_WEIGHT = "weight";
    private static final String COL_DATE = "date";
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT + " TEXT NOT NULL, " +
                COL_DATE + " TEXT NOT NULL)";
        db.execSQL(createTable);
        String createUsersTable = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)";

        db.execSQL(createUsersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            String createUsersTable = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                    COL_USERNAME + " TEXT PRIMARY KEY, " +
                    COL_PASSWORD + " TEXT)";

            db.execSQL(createUsersTable);
        }
    }

    public boolean addWeight(String weight, String date) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT, weight);
        values.put(COL_DATE, date);

        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHT,
                null,
                null,
                null,
                null,
                null,
                COL_ID + " DESC"
        );
    }
    public Cursor getStartingWeight() {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHT,
                null,
                null,
                null,
                null,
                null,
                COL_ID + " ASC",
                "1"
        );
    }
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                TABLE_WEIGHT,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    public boolean updateWeight(int id, String weight, String date) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT, weight);
        values.put(COL_DATE, date);

        int result = db.update(
                TABLE_WEIGHT,
                values,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Register a new user in the SQLite database
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }


    // Check whether the username and password match a registered user
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USERNAME},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        )) {
            return cursor.moveToFirst();
        }
    }

}