package com.example.weighttracker;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    private LinearLayout historyContainer;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        historyContainer = findViewById(R.id.historyContainer);
        databaseHelper = new DatabaseHelper(this);

        Button addWeightButton =
                findViewById(R.id.buttonAddWeight);

        Button backButton =
                findViewById(R.id.buttonBack);

        loadWeights();

        addWeightButton.setOnClickListener(view -> finish());

        backButton.setOnClickListener(view -> finish());
    }

    private void loadWeights() {

        historyContainer.removeAllViews();
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setPadding(8, 12, 8, 12);

        TextView dateHeader = new TextView(this);
        dateHeader.setText("DATE");
        dateHeader.setTextSize(16);
        dateHeader.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView weightHeader = new TextView(this);
        weightHeader.setText("WEIGHT");
        weightHeader.setTextSize(16);
        weightHeader.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView actionHeader = new TextView(this);
        actionHeader.setText("ACTION");
        actionHeader.setTextSize(16);
        actionHeader.setTypeface(null, android.graphics.Typeface.BOLD);

        dateHeader.setLayoutParams(
                new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f));

        weightHeader.setLayoutParams(
                new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        actionHeader.setLayoutParams(
                new LinearLayout.LayoutParams(0,
                        LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        headerRow.addView(dateHeader);
        headerRow.addView(weightHeader);
        headerRow.addView(actionHeader);

        historyContainer.addView(headerRow);

        Cursor cursor = databaseHelper.getAllWeights();

        if (cursor.getCount() == 0) {

            TextView emptyText = new TextView(this);
            emptyText.setText("No weight entries yet.");
            emptyText.setTextSize(18);
            emptyText.setPadding(16, 16, 16, 16);

            historyContainer.addView(emptyText);

        } else {

            while (cursor.moveToNext()) {

                int idIndex = cursor.getColumnIndex("id");
                int weightIndex = cursor.getColumnIndex("weight");
                int dateIndex = cursor.getColumnIndex("date");

                int id = cursor.getInt(idIndex);
                String weight = cursor.getString(weightIndex);
                String date = cursor.getString(dateIndex);

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(8, 12, 8, 12);

                TextView weightText = new TextView(this);

                weightText.setText(
                        date + "     " + weight + " lbs"
                );

                weightText.setTextSize(18);

                LinearLayout.LayoutParams textParams =
                        new LinearLayout.LayoutParams(
                                0,
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                1
                        );

                weightText.setLayoutParams(textParams);

                Button editButton = new Button(this);
                editButton.setText("Edit");

                editButton.setOnClickListener(view -> {
                    android.widget.EditText weightInput =
                            new android.widget.EditText(this);
                    weightInput.setText(weight);
                    weightInput.setHint("Enter weight");

                    android.widget.EditText dateInput =
                            new android.widget.EditText(this);
                    dateInput.setText(date);
                    dateInput.setHint("Enter date");

                    LinearLayout dialogLayout = new LinearLayout(this);
                    dialogLayout.setOrientation(LinearLayout.VERTICAL);
                    dialogLayout.setPadding(40, 20, 40, 20);
                    dialogLayout.addView(weightInput);
                    dialogLayout.addView(dateInput);

                    new androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("Edit Weight Entry")
                            .setView(dialogLayout)
                            .setPositiveButton("Save", (dialog, which) -> {
                                String newWeight = weightInput.getText().toString().trim();
                                String newDate = dateInput.getText().toString().trim();

                                if (!newWeight.isEmpty() && !newDate.isEmpty()) {
                                    databaseHelper.updateWeight(id, newWeight, newDate);
                                    loadWeights();
                                } else {
                                    android.widget.Toast.makeText(
                                            this,
                                            "Weight and date cannot be empty",
                                            android.widget.Toast.LENGTH_SHORT
                                    ).show();
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });

                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");

                deleteButton.setOnClickListener(view -> {

                    databaseHelper.deleteWeight(id);

                    // Refresh the rows after deletion
                    loadWeights();
                });

                row.addView(weightText);
                row.addView(editButton);
                row.addView(deleteButton);

                historyContainer.addView(row);
            }
        }

        cursor.close();
    }
}